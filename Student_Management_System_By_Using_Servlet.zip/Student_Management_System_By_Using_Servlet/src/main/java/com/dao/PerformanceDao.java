package com.dao;

import java.sql.*;
import com.model.Performance;

public class PerformanceDao {
    private static final String URL = "jdbc:mysql://localhost:3306/student_management";
    private static final String USER = "root";
    private static final String PASS = "Mahesh@123";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public boolean record(Performance p) throws SQLException {
        String sql = "INSERT INTO performance (student_id, subject, marks) VALUES (?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, p.getStudentId());
            ps.setString(2, p.getSubject());
            ps.setInt(3, p.getMarks());
            return ps.executeUpdate() > 0;
        }
    }
}
