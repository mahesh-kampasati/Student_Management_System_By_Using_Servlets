package com.dao;

import java.sql.*;
import com.model.Teacher;

public class TeacherDao {
    private static final String URL = "jdbc:mysql://localhost:3306/student_management";
    private static final String USER = "root";
    private static final String PASS = "Mahesh@123";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public boolean save(Teacher t) throws SQLException {
        String sql = "INSERT INTO teachers (user_id,name,subject) VALUES (?,?,?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, t.getUserId());
            ps.setString(2, t.getName());
            ps.setString(3, t.getSubject());
            return ps.executeUpdate()>0;
        }
    }
}