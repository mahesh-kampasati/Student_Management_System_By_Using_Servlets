package com.dao;

import java.sql.*;
import com.model.Attendance;

public class AttendanceDao {
    private static final String URL = "jdbc:mysql://localhost:3306/student_management";
    private static final String USER = "root";
    private static final String PASS = "Mahesh@123";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public boolean record(Attendance a) throws SQLException {
        String sql = "INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, a.getStudentId());
            ps.setDate(2, a.getDate());
            ps.setString(3, a.getStatus());
            return ps.executeUpdate() > 0;
        }
    }
}
