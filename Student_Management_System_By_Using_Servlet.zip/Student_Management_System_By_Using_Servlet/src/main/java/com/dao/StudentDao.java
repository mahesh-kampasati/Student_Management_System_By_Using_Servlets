package com.dao;

import java.sql.*;
import com.model.Student;

public class StudentDao {
    private static final String URL = "jdbc:mysql://localhost:3306/student_management";
    private static final String USER = "root";
    private static final String PASS = "Mahesh@123";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public boolean save(Student s) throws SQLException {
        String sql = "INSERT INTO students (user_id,name,stream,percentage,gender) VALUES (?,?,?,?,?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, s.getUserId());
            ps.setString(2, s.getName());
            ps.setString(3, s.getStream());
            ps.setDouble(4, s.getPercentage());
            ps.setString(5, s.getGender());
            return ps.executeUpdate()>0;
        }
    }
}