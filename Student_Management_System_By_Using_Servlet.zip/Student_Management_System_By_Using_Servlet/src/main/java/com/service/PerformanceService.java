package com.service;

import com.dao.PerformanceDao;
import com.model.Performance;

public class PerformanceService {
    private PerformanceDao dao = new PerformanceDao();

    public boolean recordPerformance(Performance p) throws Exception {
        return dao.record(p);
    }
}
