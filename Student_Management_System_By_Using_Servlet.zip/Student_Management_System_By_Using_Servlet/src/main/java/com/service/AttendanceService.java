package com.service;

import com.dao.AttendanceDao;
import com.model.Attendance;

public class AttendanceService {
    private AttendanceDao dao = new AttendanceDao();

    public boolean recordAttendance(Attendance attendance) throws Exception {
        return dao.record(attendance);
    }
}
