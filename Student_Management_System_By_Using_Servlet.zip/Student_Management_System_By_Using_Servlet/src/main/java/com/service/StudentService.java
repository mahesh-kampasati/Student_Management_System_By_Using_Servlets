package com.service;

import com.dao.StudentDao;
import com.model.Student;

public class StudentService {
    private StudentDao dao = new StudentDao();

    public boolean addStudent(Student s) throws Exception {
        return dao.save(s);
    }
}