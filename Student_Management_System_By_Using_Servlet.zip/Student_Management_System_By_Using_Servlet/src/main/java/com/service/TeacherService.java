package com.service;

import com.dao.TeacherDao;
import com.model.Teacher;

public class TeacherService {
    private TeacherDao dao = new TeacherDao();

    public boolean addTeacher(Teacher t) throws Exception {
        return dao.save(t);
    }
}