package com.service;

import com.dao.UserDao;
import com.model.User;

public class UserService {
    private UserDao dao = new UserDao();

    public User authenticate(String email, String password) throws Exception {
        return dao.findByEmailAndPassword(email, password);
    }

    public boolean register(User u) throws Exception {
        return dao.register(u);
    }
}