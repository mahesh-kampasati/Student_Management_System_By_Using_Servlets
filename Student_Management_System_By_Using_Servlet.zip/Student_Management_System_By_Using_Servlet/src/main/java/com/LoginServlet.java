package com;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_management", "root", "Mahesh@123");


            PreparedStatement ps = con.prepareStatement("SELECT role FROM users WHERE email=? AND password=?");
            ps.setString(1, email);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String role = rs.getString("role");
                HttpSession session = request.getSession();
                session.setAttribute("role", role);
                session.setAttribute("email", email);

                switch (role) {
                    case "Admin":
                        response.sendRedirect("admin_dashboard.html");
                        break;
                    case "Teacher":
                        response.sendRedirect("teacher_dashboard.html");
                        break;
                    case "Student":
                        response.sendRedirect("student_dashboard.html");
                        break;
                    default:
                        response.sendRedirect("login.html");
                }
            } else {
                response.getWriter().println("Invalid credentials. <a href='login.html'>Try again</a>");
            }
            con.close();

        } catch (Exception e) {
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
