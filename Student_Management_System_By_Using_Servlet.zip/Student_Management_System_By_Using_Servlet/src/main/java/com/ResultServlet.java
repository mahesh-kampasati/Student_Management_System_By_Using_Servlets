package com;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ResultServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int studentId = Integer.parseInt(request.getParameter("studentId"));

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        double totalMarks = 0;
        double obtainedMarks = 0;
        int subjectCount = 0;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/student_management", "root", "Mahesh@123");

            ps = con.prepareStatement(
                "SELECT subject, marks, total_marks, teacher_name FROM performance WHERE student_id = ?");
            ps.setInt(1, studentId);
            rs = ps.executeQuery();

            out.println("<html><head><title>Result</title><link rel='stylesheet' href='./styles.css'></head><body>");
            out.println("<div class='container'>");
            out.println("<h2>Result for Student ID: " + studentId + "</h2>");

            out.println("<table border='1' cellpadding='10' cellspacing='0'>");
            out.println("<tr><th>Subject</th><th>Marks Obtained</th><th>Total Marks</th><th>Teacher</th></tr>");

            while (rs.next()) {
                String subject = rs.getString("subject");
                double marksObtained = rs.getDouble("marks");
                double total = rs.getDouble("total_marks");
                String teacher = rs.getString("teacher_name");

                obtainedMarks += marksObtained;
                totalMarks += total;
                subjectCount++;

                out.println("<tr><td>" + subject + "</td><td>" + marksObtained + "</td><td>" + total + "</td><td>" + teacher + "</td></tr>");
            }

            out.println("</table>");

            if (subjectCount > 0) {
                double percentage = (obtainedMarks / totalMarks) * 100;
                String grade;

                if (percentage >= 90) grade = "A+";
                else if (percentage >= 80) grade = "A";
                else if (percentage >= 70) grade = "B";
                else if (percentage >= 60) grade = "C";
                else if (percentage >= 50) grade = "D";
                else grade = "F";

                out.println("<div style='text-align: right; margin-top: 20px;'>");
                out.println("<strong>Percentage:</strong> " + String.format("%.2f", percentage) + "%<br>");
                out.println("<strong>Grade:</strong> " + grade);
                out.println("</div>");
            } else {
                out.println("<p>No results found for this student.</p>");
            }

            out.println("</div></body></html>");

        } catch (Exception e) {
            out.println("<p>Error: " + e.getMessage() + "</p>");
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    }
}
