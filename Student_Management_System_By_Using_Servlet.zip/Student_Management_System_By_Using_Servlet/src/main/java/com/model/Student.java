package com.model;

public class Student {
    private int id;
    private int userId;
    private String name;
    private String stream;
    private double percentage;
    private String gender;

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getStream() { return stream; }
    public void setStream(String stream) { this.stream = stream; }

    public double getPercentage() { return percentage; }
    public void setPercentage(double percentage) { this.percentage = percentage; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
}
