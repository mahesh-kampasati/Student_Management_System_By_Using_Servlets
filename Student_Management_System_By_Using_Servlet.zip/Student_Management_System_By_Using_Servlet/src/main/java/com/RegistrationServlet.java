package com;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RegistrationServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String gender = request.getParameter("gender");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        String stream = request.getParameter("stream");
        String percentageStr = request.getParameter("percentage");
        String subject = request.getParameter("subject");

        Connection con = null;
        PreparedStatement psUser = null;
        PreparedStatement psDetails = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_management", "root", "Mahesh@123");

            // Insert into users
            psUser = con.prepareStatement("INSERT INTO users (email, password, role, userName, gender) VALUES (?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            psUser.setString(1, email);
            psUser.setString(2, password);
            psUser.setString(3, role);
            psUser.setString(4, name);
            psUser.setString(5, gender);
            int rows = psUser.executeUpdate();

            if (rows > 0) {
                rs = psUser.getGeneratedKeys();
                if (rs.next()) {
                    int userId = rs.getInt(1);

                    if ("Student".equalsIgnoreCase(role)) {
                        psDetails = con.prepareStatement("INSERT INTO students (user_id, name, stream, percentage, gender) VALUES (?, ?, ?, ?, ?)");
                        psDetails.setInt(1, userId);
                        psDetails.setString(2, name);
                        psDetails.setString(3, stream);
                        psDetails.setDouble(4, Double.parseDouble(percentageStr));
                        psDetails.setString(5, gender);
                    } else if ("Teacher".equalsIgnoreCase(role)) {
                        psDetails = con.prepareStatement("INSERT INTO teachers (user_id, name, subject, email, password, gender) VALUES (?, ?, ?, ?, ?, ?)");
                        psDetails.setInt(1, userId);
                        psDetails.setString(2, name);
                        psDetails.setString(3, subject);
                        psDetails.setString(4, email);
                        psDetails.setString(5, password);
                        psDetails.setString(6, gender);
                    }


                    if (psDetails != null) {
                        psDetails.executeUpdate();
                    }

                    response.getWriter().println("Registration successful! <a href='login.html'>Login here</a>");
                }
            } else {
                response.getWriter().println("User registration failed.");
            }

        } catch (Exception e) {
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (psUser != null) psUser.close(); } catch (Exception e) {}
            try { if (psDetails != null) psDetails.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); 
            } 
            catch (Exception e) {}
        }
    }
}
