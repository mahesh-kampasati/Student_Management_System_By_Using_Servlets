package com;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class PerformanceServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int studentId = Integer.parseInt(request.getParameter("studentId"));
        String subject = request.getParameter("subject");
        int marks = Integer.parseInt(request.getParameter("marks"));
        int totalMarks = Integer.parseInt(request.getParameter("totalMarks"));
        String teacherName = request.getParameter("teacherName");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_management", "root", "Mahesh@123");

            PreparedStatement ps = con.prepareStatement("INSERT INTO performance (student_id, subject, marks, total_marks, teacher_name) VALUES (?, ?, ?, ?, ?)");
            ps.setInt(1, studentId);
            ps.setString(2, subject);
            ps.setInt(3, marks);
            ps.setInt(4, totalMarks);
            ps.setString(5, teacherName);

            int rows = ps.executeUpdate();
            response.getWriter().println(rows > 0 ? "Performance recorded!" : "Failed to record performance.");
            con.close();

        } catch (Exception e) {
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
