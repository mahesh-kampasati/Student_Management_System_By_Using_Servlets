

function validateLoginForm() {
    const email = document.forms["loginForm"]["email"].value;
    const password = document.forms["loginForm"]["password"].value;
    if (email === "" || password === "") {
        alert("Both fields are required");
        return false;
    }
    return true;
}